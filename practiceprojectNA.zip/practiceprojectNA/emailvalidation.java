package practiceprojectNA;
import java.util.ArrayList;

public class emailvalidation {

	    public static void main(String[] args) {
	        
	        ArrayList<String> emailID = new ArrayList<String>();
	        
	        emailID.add("elena.hasler@gmx.com");
	        emailID.add("caroline.klein@gmx.com");
	        emailID.add("klaus.hoch@gmx.com");
	        emailID.add("damon.neumann@gmx.com");
	        emailID.add("stefan.fiesler@gmx.com");
	        emailID.add("hayley.kramm@gmx.com");
	        emailID.add("rabheka.neuwirth@gmx.com");
	        
	   
	        String searcElement = "elena.hasler@gmx.com";
	        
	                for(int i=0; i<emailID.size(); i++) {
	                    
	                    System.out.println(emailID.get(i));
	                    
	                    if(searcElement==emailID.get(i)) {
	                        
	                        System.out.println("\n");
	                        
	                        System.out.println("email ID- " + searcElement + " - found");
	                        
	                        break;
	                        
	                    }
	                }

	    }

	}
