
import java.io.File;
public class fileinformation {
	public static void main(String[] args) {
		File myObj = new File("myfile.txt");
		if(myObj.exists()) {
			System.out.println("File name:"+myObj.getName());
			System.out.println("Absolute path: "+ myObj.getAbsolutePath());
			System.out.println("Writeble:" + myObj.canWrite());
			System.out.println("Readable:" + myObj.canRead());
			System.out.println("File size:" + myObj.length());
		}
		else {
			System.out.println("file not exists");
		}
		
	}

}
