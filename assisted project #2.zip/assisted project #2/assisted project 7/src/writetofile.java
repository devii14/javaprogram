

import java.io.FileWriter;
import java.io.IOException;


public class writetofile {
	public static void main(String[] args) {
		try {
			FileWriter myWriter = new FileWriter("myfile.txt");
			myWriter.write("you are best i am happy for you");
			myWriter.close();
			System.out.println("sucessfully wrote");
			
		}
		catch (IOException e){
		System.out.println("Error");
		e.fillInStackTrace();
			
		}
	}
}
