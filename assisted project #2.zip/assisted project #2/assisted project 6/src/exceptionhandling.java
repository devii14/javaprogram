
public class exceptionhandling {
	static void check(int age) throws Exception
	{
		if(age<18)
			System.out.println("you can vote");
		else
			System.out.println("you cant vote");
	}

	static void test() throws Exception
	{
		check(14);
	}

	public static void main(String[] args) {

		 try {
			test();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

