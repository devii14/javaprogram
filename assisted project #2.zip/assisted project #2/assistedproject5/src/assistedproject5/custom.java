package assistedproject5;

public class custom extends Exception {   
	public static void main(String args[])
	{
		try {
			throw new custom ();
		}
		catch (custom ex) {
			System.out.println("wrong");
			System.out.println(ex.getMessage());
		}
	}
}
