package assistedproject5;
import java.io.*;

public class Finally {
	
		public static void main(String[] args)
		{
			try {
				System.out.println("inside try block");
			}
			catch (ArithmeticException e) {

				System.out.println("catch : exception handled.");
			}
			finally {
				
			System.out.println("finally : i execute always.");
			}
		}
	}


