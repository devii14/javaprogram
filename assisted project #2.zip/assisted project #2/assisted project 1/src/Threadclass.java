
public class Threadclass implements Runnable{
			
			public void run() {
				
				for(int i=1; i<5; i++) {
					
				System.out.println(i+ "  "+Thread.currentThread().getName());
		}}

		public static void main(String[] args) {
			Threadclass ins1= new  Threadclass();
			Threadclass ins2= new  Threadclass();
			
			Thread t1= new Thread(ins1);
			Thread t2= new Thread(ins2);
			
			t1.setName("first");
			t2.setName("second");
			
			t1.start();
			t2.start();
			
		}
		}
