package t;

public record print() {

}
