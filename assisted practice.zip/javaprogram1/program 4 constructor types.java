package javaprogram1;

public class constructor {
		  private String name;
		  constructor () {
		    System.out.println("Constructor Called:");
		    name = "java";
		  }

		  public static void main(String[] args) {
		   constructor obj = new constructor();
		    System.out.println("The programming is in " + obj.name);
		  }
		}
