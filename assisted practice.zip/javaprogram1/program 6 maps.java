package javaprogram1;
import java.util.*;  

public class maps {
	 public static void main(String args[]){  
	Map<Integer,String> map=new HashMap<Integer,String>();          
	      map.put(10,"stefan");    
	      map.put(20,"damon");    
	      map.put(30,"klaus");    
	      map.entrySet()  
	      .stream()  
	      .sorted(Map.Entry.comparingByValue())  
	      .forEach(System.out::println);  
	 }  
	}  
