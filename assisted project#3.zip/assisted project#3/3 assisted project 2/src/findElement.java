
public class findElement {
		   
		public void sortArr(int arr[])  
		{  
		int size = arr.length;  
		  
		for(int i = 0; i < size; i++)  
		{  
		int temp = i;  
		for(int j = i + 1; j < size; j++)  
		{  
		if(arr[temp] > arr[j])  
		{  
		temp = j;  
		}  
		  
		}  	  
		if(temp != i)  
		{  
		int t = arr[i];  
		arr[i] = arr[temp];  
		arr[temp] = t;   
		}  
		}  
		}  
		  
		 
		public int findKthSmallest(int arr[], int k)  
		{  
		sortArr(arr);  
		return arr[k - 1];  
		}  	  
		public static void main(String argvs[])  
		{  
		  
			findElement obj = new findElement();  
		  
		int arr[] = {5, 3, 7, 9, 11, 8, 12, 4};  
		  
		int size = arr.length;  
		int k = 4;  
		  
		System.out.println("list  of num ");  
		for(int i = 0; i < size; i++)  
		{  
		System.out.print(arr[i] + " ");  
		}  
		  
		int element = obj.findKthSmallest(arr, k);  
		  
		System.out.println();  
		System.out.println("The " + k + "th smallest element of the list is: " + element);  
		  
		System.out.println("\n");  
		 
		
	}
		}


