package addRemove;
import java.util.*;

public class addRemoveStack {
		public static void main(String args[])
		{
			Stack<String> line = new Stack<String>();

			line.add("i am");
			line.add("happy");
			line.add("for");
			line.add("you");
			line.add("and");
			line.add("harini");
			System.out.println("Stack: " + line);
			String remove_elements = line.remove(5 );

			System.out.println("Removed element: "+ remove_elements);


			System.out.println("Final line: "	+ line);
		}
	}


