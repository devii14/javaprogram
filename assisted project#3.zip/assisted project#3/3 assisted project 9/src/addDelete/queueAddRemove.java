package addDelete;
import java.util.*;

public class queueAddRemove {
		public static void main(String args[])
		{
			Queue<String> list = new PriorityQueue<>();

			 list.add("alwways");
			 list.add("forever");
			 list.add("happy");
			System.out.println("before removing:"+ list);
			
			 list.remove("forever");

			System.out.println(" After removing :" + list);
			
			  
		}

	}


