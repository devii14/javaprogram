
	import java.util.Scanner;

public class LongestIncreasingsubsequence {
	    public int[] lis(int[] X)
	    {        
	        int a= X.length - 1;
	        int[] b = new int[a + 1];  
	        int[] P = new int[a + 1]; 
	        int L = 0;
	 
	        for (int i = 1; i < a + 1; i++)
	        {
	            int j = 0;
	 
	
	            for (int pos = L ; pos >= 1; pos--)
	            {
	                if (X[b[pos]] < X[i])
	                {
	                    j = pos;
	                    break;
	                }
	            }            
	            P[i] = b[j];
	            if (j == L || X[i] < X[b[j + 1]])
	            {
	                b[j + 1] = i;
	                L = Math.max(L,j + 1);
	            }
	        }
	 
	        /** backtrack **/
	 
	        int[] result = new int[L];
	        int pos = b[L];
	        for (int i = L - 1; i >= 0; i--)
	        {
	        	result[i] = X[pos];
	            pos = P[pos];
	        }
	        return result;             
	    }
	 	    public static void main(String[] args) 
	    {    
	        Scanner scan = new Scanner(System.in);
	        System.out.println("Longest Increasing Subsequence Algorithm Test\n");
	 
	        System.out.println("Enter number of elements");
	        int n = scan.nextInt();
	        int[] arr = new int[n + 1];
	        System.out.println("\nEnter "+ n +" elements");
	        for (int i = 1; i <= n; i++)
	            arr[i] = scan.nextInt();
	        LongestIncreasingsubsequence obj = new LongestIncreasingsubsequence(); 
	        int[] result = obj.lis(arr);       	 
	        System.out.print("\nLongest Increasing Subsequence : ");
	        for (int i = 0; i < result.length; i++)
	        	System.out.print(result[i] +" ");
	        System.out.println();
    }
}
